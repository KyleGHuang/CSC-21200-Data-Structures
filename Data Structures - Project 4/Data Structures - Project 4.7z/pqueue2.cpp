// FILE: pqueue2.cxx
// IMPLEMENTS: PriorityQueue (See pqueue2.h for documentation.)
//-- IMPLEMENTED BY: Kyle Huang khuang005@citymail.cuny.edu
//
// NOTE: You will need -lm at the end of your compile line to pick up
// the math library!

// INVARIANT for the PriorityQueue Class:
//   1. The member variable many_items is the number of items in the
//      PriorityQueue.
//   2. The items themselves are stored in the member variable heap,
//      which is a partially filled array organized to follow the usual
//      heap storage rules from Chapter 11 of the class notes.
// NOTE: Private helper functions are implemented at the bottom of this
// file along with their precondition/postcondition contracts.

#include <assert.h>    // Provides assert function
#include <iomanip>   // Provides setw
#include <iostream>  // Provides cin, cout
#include <math.h>      // Provides log2
#include "pqueue2.h"

using namespace std;

PriorityQueue::PriorityQueue()
{
    many_items = 0;
}

void PriorityQueue::insert(const Item& entry, unsigned int priority)
{
    assert(many_items < CAPACITY);

    if(is_empty()) {
        heap[0].data = entry;
        heap[0].priority = priority;
        many_items++;
    }
    else {
        heap[many_items].data = entry;
        heap[many_items].priority = priority;
        many_items++;


        //Reheapification Upwards
        int index = many_items - 1;

        while (index != 0 && heap[index].priority > parent_priority(index)) {
            swap_with_parent(index);
            index = (index - 1) / 2;
        }
    }
}

//Part 2
// note: treat it as the combination of top() and pop()
PriorityQueue::Item PriorityQueue::get_front()
// Precondition: size( ) > 0.
// Postcondition: The highest priority item has been returned and has been
// removed from the PriorityQueue. (If several items have equal priority,
// then there is no guarantee about which one will come out first!
// This differs from our first priority queue.)
{
    assert(size() > 0);

    double top = heap[0].data;

    if (many_items == 1) {
        heap[0].data = NULL;
        heap[0].priority = NULL;
        many_items--;

        return top;
    }

    //Set root as last index
    heap[0].data = heap[many_items - 1].data;
    heap[0].priority = heap[many_items - 1].priority;

    heap[many_items - 1].data = NULL;
    heap[many_items - 1].priority = NULL;

    many_items--;


    //Reheapification Downwards
    int index = 0;

    if (many_items == 1)
        return top;
    else {
        while (!is_leaf(index) && heap[index].priority < big_child_priority(index)) {
            index = big_child_index(index);
            swap_with_parent(index);
        }

        return top;
    }
}

//Part 2
bool PriorityQueue::is_leaf(size_t i) const
// Precondition: (i < many_items)
// Postcondition: If heap[i] has no children in the heap, then the function
// returns true. Otherwise the function returns false.
{
    assert(i < many_items);

    int left_child = 2 * i + 1;
    int right_child = 2 * i + 2;

    if (left_child >= many_items && right_child >= many_items) return true;
    else return false;
}

size_t PriorityQueue::parent_index(size_t i) const
// Precondition: (i > 0) && (i < many_items)
// Postcondition: The return value is the index of the parent of heap[i].
{
    assert(i > 0 && i < many_items);

    return (i - 1) / 2;
}

unsigned int PriorityQueue::parent_priority(size_t i) const
// Precondition: (i > 0) && (i < many_items)
// Postcondition: The return value is the priority of the parent of heap[i].
{
    assert(i > 0 && i < many_items);

    return heap[parent_index(i)].priority;
}

//Part 2
size_t PriorityQueue::big_child_index(size_t i) const
// Precondition: !is_leaf(i)
// Postcondition: The return value is the index of one of heap[i]'s children.
// This is the child with the larger priority.
{
    assert(!is_leaf(i));

    int left_child = 2 * i + 1;
    int right_child = 2 * i + 2;

    if (heap[left_child].priority > heap[right_child].priority)
        return left_child;
    else 
        return right_child;
}

//Part 2
unsigned int PriorityQueue::big_child_priority(size_t i) const
// Precondition: !is_leaf(i)
// Postcondition: The return value heap[big_child_index(i)].priority
{
    assert(!is_leaf(i));

    return heap[big_child_index(i)].priority;
}

void PriorityQueue::swap_with_parent(size_t i)
// Precondition: (i > 0) && (i < many_items)
// Postcondition: heap[i] has been swapped with heap[parent_index(i)]
{
    assert(i > 0 && i < many_items);

    Item tempdata;
    unsigned int temppriority;

    tempdata = heap[i].data;
    temppriority = heap[i].priority;

    heap[i].data = heap[parent_index(i)].data;
    heap[i].priority = heap[parent_index(i)].priority;

    heap[parent_index(i)].data = tempdata;
    heap[parent_index(i)].priority = temppriority;
}